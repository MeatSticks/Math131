function [output, match] = template_matching_normcorr(img, template, threshold)

output = img;
[x,y,z] = size(template);
[a,b,c] = size(img);
array = [x,y];
s = 0;
img = padarray(img, array, s, 'both');

for u = 1 + floor(x/2) : size(img, 2) - floor(x/2)
    
    for v = 1 + floor(y/2) : size(img, 1) - floor(y/2)
    
    x1 = u - floor(x/2); 
    x2 = u + floor(x/2);
    y1 = v - floor(y/2); 
    y2 = v + floor(y/2);
    
    patch = img(y1:y2, x1:x2);
    %patch = patch(:);
    
% SSD
    patch = patch(:) - mean(patch(:));
    patch = rdivide(patch, norm(patch)); 
    template = template(:) - mean(template(:));
    template = rdivide(template, norm(template));
    value = dot(patch, template);
    output(v - floor(y/2), u - floor(x/2)) = value;
    
    end
end

match = (output > threshold);